
void test() {
  int a, b, c, d, e, f;
  c = f;
  if (e > 0) {
    b = a - e;
    e = b + c;
  } else {
    e = b + c;
  }
  a = b + c;
}
