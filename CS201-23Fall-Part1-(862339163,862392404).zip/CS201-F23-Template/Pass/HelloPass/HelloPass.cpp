#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Function.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/CFG.h"
#include <string>

using namespace llvm;

#define DEBUG_TYPE "HelloPass"

namespace
{
  struct HelloPass : public FunctionPass
  {
    static char ID;
    HelloPass() : FunctionPass(ID) {}

    bool runOnFunction(Function &F) override
    {
      errs() << "HelloPass runOnFunction: ";
      errs() << F.getName() << "\n";
      for (auto &basic_block : F)
      {
        BasicBlock *BB = &basic_block;
        for (auto &inst : basic_block)
        {
          errs() << inst << "\n";
          if (inst.getOpcode() == Instruction::Load)
          {
            errs() << "This is Load\n";
          }
          if (inst.getOpcode() == Instruction::Store)
          {
            errs() << "This is Store\n";
          }
          if (inst.isBinaryOp())
          {
            errs() << "Op Code:" << inst.getOpcodeName() << "\n";
            if (inst.getOpcode() == Instruction::Add)
            {
              errs() << "This is Addition\n";
            }
            if (inst.getOpcode() == Instruction::Sub)
            {
              errs() << "This is Subtraction\n";
            }
            if (inst.getOpcode() == Instruction::Mul)
            {
              errs() << "This is Multiplication\n";
            }
            if (inst.getOpcode() == Instruction::SDiv)
            {
              errs() << "This is Division\n";
            }
            // Check for other operation types as needed

            auto *ptr = dyn_cast<User>(&inst);
            for (auto it = ptr->op_begin(); it != ptr->op_end(); ++it)
            {
              errs() << "\t" << *(*it) << "\n";
            }
          }
        }
        int pred_count = 0;
        for (BasicBlock *Pred : predecessors(BB))
        {
          pred_count += 1;
        }
        errs() << "\t predecessors " << pred_count << "\n";
        int s_count = 0;
        for (BasicBlock *Succ : successors(BB))
        {
          s_count += 1;
        }
        errs() << "\t successors " << s_count << "\n";
      }
      return false;
    }
  };

  char HelloPass::ID = 0;
  static RegisterPass<HelloPass> X("Hello", "Hello Pass",
                                   false /* Only looks at CFG */,
                                   false /* Analysis Pass */);
}
